using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pickup : MonoBehaviour
{
    public AudioSource audioSource;
    public AudioClip pickupClip;

    //public AudioSource ZomAudioSource;
    //public AudioClip ZombieKillClip;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Book"))
        {
            Destroy(other.gameObject);
            audioSource.PlayOneShot(pickupClip);
        }

        if (other.gameObject.CompareTag("Zombie") && this.gameObject.CompareTag("Knife"))
        {
            Destroy(other.gameObject);
            //ZomAudioSource.PlayOneShot(ZombieKillClip);
        }

    }
}
